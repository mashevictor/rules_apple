This directory contains resources, such as app icons and launch storyboards,
that are referenced by other examples.
